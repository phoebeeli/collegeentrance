#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_QtGuifirsttryApplication1.h"

class QtGuifirsttryApplication1 : public QMainWindow
{
	Q_OBJECT

public:
	QtGuifirsttryApplication1(QWidget *parent = Q_NULLPTR);

private:
	Ui::QtGuifirsttryApplication1Class ui;

private slots:
	void button();
	int getitem();
};
