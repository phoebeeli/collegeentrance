/********************************************************************************
** Form generated from reading UI file 'QtGuifirsttryApplication1.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTGUIFIRSTTRYAPPLICATION1_H
#define UI_QTGUIFIRSTTRYAPPLICATION1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtGuifirsttryApplication1Class
{
public:
    QWidget *centralWidget;
    QPushButton *StartSorting;
    QLabel *label_2;
    QPushButton *select;
    QComboBox *comboBox;
    QLabel *label;
    QLabel *consequencelabel;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtGuifirsttryApplication1Class)
    {
        if (QtGuifirsttryApplication1Class->objectName().isEmpty())
            QtGuifirsttryApplication1Class->setObjectName(QStringLiteral("QtGuifirsttryApplication1Class"));
        QtGuifirsttryApplication1Class->resize(1600, 1000);
        centralWidget = new QWidget(QtGuifirsttryApplication1Class);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        StartSorting = new QPushButton(centralWidget);
        StartSorting->setObjectName(QStringLiteral("StartSorting"));
        StartSorting->setGeometry(QRect(210, 410, 161, 71));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font.setPointSize(13);
        StartSorting->setFont(font);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(120, 150, 1421, 251));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font1.setPointSize(29);
        label_2->setFont(font1);
        label_2->setAlignment(Qt::AlignCenter);
        select = new QPushButton(centralWidget);
        select->setObjectName(QStringLiteral("select"));
        select->setGeometry(QRect(1240, 410, 181, 51));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font2.setPointSize(14);
        select->setFont(font2);
        comboBox = new QComboBox(centralWidget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(810, 420, 411, 41));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(220, 510, 201, 81));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\345\276\256\350\275\257\351\233\205\351\273\221"));
        font3.setPointSize(11);
        label->setFont(font3);
        consequencelabel = new QLabel(centralWidget);
        consequencelabel->setObjectName(QStringLiteral("consequencelabel"));
        consequencelabel->setGeometry(QRect(530, 420, 281, 51));
        consequencelabel->setFont(font3);
        QtGuifirsttryApplication1Class->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QtGuifirsttryApplication1Class);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1600, 22));
        QtGuifirsttryApplication1Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QtGuifirsttryApplication1Class);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        QtGuifirsttryApplication1Class->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QtGuifirsttryApplication1Class);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        QtGuifirsttryApplication1Class->setStatusBar(statusBar);

        retranslateUi(QtGuifirsttryApplication1Class);
        QObject::connect(StartSorting, SIGNAL(clicked()), QtGuifirsttryApplication1Class, SLOT(button()));

        QMetaObject::connectSlotsByName(QtGuifirsttryApplication1Class);
    } // setupUi

    void retranslateUi(QMainWindow *QtGuifirsttryApplication1Class)
    {
        QtGuifirsttryApplication1Class->setWindowTitle(QApplication::translate("QtGuifirsttryApplication1Class", "QtGuifirsttryApplication1", nullptr));
        StartSorting->setText(QApplication::translate("QtGuifirsttryApplication1Class", "\345\274\200\345\247\213", nullptr));
        label_2->setText(QApplication::translate("QtGuifirsttryApplication1Class", "\351\253\230\346\240\241\351\253\230\350\200\203\346\213\233\347\224\237\350\207\252\345\212\250\345\214\226\345\275\225\345\217\226\350\276\205\345\212\251\347\263\273\347\273\237", nullptr));
        select->setText(QApplication::translate("QtGuifirsttryApplication1Class", "\346\237\245\350\257\242", nullptr));
        comboBox->setItemText(0, QApplication::translate("QtGuifirsttryApplication1Class", "Peking University", nullptr));
        comboBox->setItemText(1, QApplication::translate("QtGuifirsttryApplication1Class", "Beijing University of Technology", nullptr));
        comboBox->setItemText(2, QApplication::translate("QtGuifirsttryApplication1Class", "Central University of Finance and Economics", nullptr));
        comboBox->setItemText(3, QApplication::translate("QtGuifirsttryApplication1Class", "Beijing Institute of Technology", nullptr));
        comboBox->setItemText(4, QApplication::translate("QtGuifirsttryApplication1Class", "Capital Medical University", nullptr));
        comboBox->setItemText(5, QApplication::translate("QtGuifirsttryApplication1Class", "Fudan University", nullptr));
        comboBox->setItemText(6, QApplication::translate("QtGuifirsttryApplication1Class", "East China Normal University", nullptr));
        comboBox->setItemText(7, QApplication::translate("QtGuifirsttryApplication1Class", "Shanghai International Studies University", nullptr));
        comboBox->setItemText(8, QApplication::translate("QtGuifirsttryApplication1Class", "University of International Business and Economics", nullptr));
        comboBox->setItemText(9, QApplication::translate("QtGuifirsttryApplication1Class", "Beijing Normal University", nullptr));
        comboBox->setItemText(10, QApplication::translate("QtGuifirsttryApplication1Class", "Beijing Foreign Studies University", nullptr));
        comboBox->setItemText(11, QApplication::translate("QtGuifirsttryApplication1Class", "Beijing International Stuies University", nullptr));

        label->setText(QString());
        consequencelabel->setText(QApplication::translate("QtGuifirsttryApplication1Class", "\346\214\211\351\231\242\346\240\241\346\237\245\350\257\242\345\275\225\345\217\226\347\273\223\346\236\234", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QtGuifirsttryApplication1Class: public Ui_QtGuifirsttryApplication1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTGUIFIRSTTRYAPPLICATION1_H
