#include <iostream>
#include <string>
#include <stdlib.h>
#include <sstream>

#include "rwexcel.h"
#define totalnum 2

int main() {
	Student *student[totalnum];
	for (int i = 0; i < totalnum; i++) {
		student[i] = new Student();
	}
	University *university[totalnum];
	for (int i = 0; i < totalnum; i++) {
		university[i] = new University();
	}
	File *file = new File();
	//file->WriteUniversityFile();
	//file->WriteStudentFile();
	//file->ReadStudentFile(student,totalnum);
	file->ReadUniversityFile(university, totalnum);

	/*for (int i = 0; i < totalnum; i++) {
		cout << student[i]->getCandidateNum() << "  ";
		cout << student[i]->getCandiName() << "  " ;
		for (int j = 1; j < 6; j++) {
			cout << student[i]->getScore(j) << "  ";
		}
		cout << endl << "   ";
		for (int j = 0; j < 6; j++) {
			cout << student[i]->getAspirationschool(j) << "  ";
			for (int k = 1; k < 6; k++) {
				cout << student[i]->getspecificMajor(j, k) << " ";
			}
			cout << "   ";
		}
		cout << endl << "   ";
		cout << "isreassign:" << student[i]->getisReassign() << "  " << "isrelegated:" << student[i]->getRelegated();
		cout << endl;
	}*/
	
	//cout << student[1]->getCandiName() << endl;
	system("pause");
	return 0;

}