#include "QtGuifirsttryApplication1.h"
#include "systemtest.h"

QtGuifirsttryApplication1::QtGuifirsttryApplication1(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}

void QtGuifirsttryApplication1::button() {
	QString temp;
	double a = 1.1;
	maintime();
	//ui.label->setText(temp.setNum(a));
	ui.label->setText("FINISHED");
}

int QtGuifirsttryApplication1::getitem() {
	int Index;
	Index=ui.comboBox->currentIndex();
	return Index;
}
