#include <iostream>
#include <string>
#include "majorplan.h"
#include "university.h"
using namespace std;

#define majornum 5

University::University() {
	UniversityNum = 0;
	UniversityName = "NULL";
	Plannum = 5;
	Actualnum = 0;
	int i = 0;
	for (i = 0; i < majornum; i++) {						//Major
		Major[i] = new MajorPlan();
	}
}

University::University(int universitynum, string universityname, int plannum, int actualnum, MajorPlan major[majornum]) {
	UniversityNum = universitynum;
	UniversityName = universityname;
	Plannum = plannum;
	Actualnum = actualnum;
	int i = 0;
	for (i = 0; i < majornum; i++) {						//Major
		Major[i] = new MajorPlan();
	}
}

void University::increaseActualnum() {
	Actualnum = Actualnum + 1;
}

void University::decreaseActualnum() {
	Actualnum = Actualnum - 1;
}

void University::increaseMajorActualnum(int majornumber) {
	Major[majornumber-1]->increaseActualnum();
}

void University::setUniversityNum(int universnum) {
	UniversityNum = universnum;
}

void University::setUniversityName(string universname) {
	UniversityName = universname;
}

void University::setUniversityPlannum(int plannum) {
	Plannum = plannum;
}

void University::setUniversityActualnum(int actualnum) {
	Actualnum = actualnum;
}

void University::setUniversityMajorTotalnum(int totalnum) {
	majortotalnum = totalnum;
}

void University::setMajorNum(int majornumber, int majornumm) {
	Major[majornumber]->setMajorNum(majornumm);
}

void University::setMajorName(int majornumber, string majorname) {
	Major[majornumber]->setMajorName(majorname);
}

void University::setMajorPlannum(int majornumber, int majorplannum) {
	Major[majornumber]->setMajorPlannum(majorplannum);
}

void University::setMajorActualnum(int majornumber, int majoractualnum) {
	Major[majornumber]->setMajorActualnum(majoractualnum);
}

int University::getMajornum() {
	return majornum;
}

int University::getUniversitynum() {
	return UniversityNum;
}

string University::getUniversityname() {
	return UniversityName;
}

MajorPlan* University::getUniversitymajor(int num) {
	return Major[num-1];
}

bool University::isFull() {
	if (Plannum > Actualnum) { return false; }
	else { return true; }
}

bool University::isMajorFull(int majornumber) {
	if ((Major[majornumber-1]->getMajorPlannum()) > (Major[majornumber-1]->getMajorAcutualnum())) {
		return false; 
	}
	else { return true; }
}