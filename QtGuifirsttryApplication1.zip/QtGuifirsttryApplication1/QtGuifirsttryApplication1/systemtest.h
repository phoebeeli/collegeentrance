#pragma once

#ifndef SYSTEMTEST_H
#define SYSTEMTEST_H

#include "student.h"
#include "university.h"

void AcceptDistribution(Student *student, University *university);		//���ӷ���
void OutputScreen(Student *student[], University *university[]);
int maintime();
void searchSpecificUniStu(int universitynum, Student *student[], int totalstunum);

#endif // !SYSTEMTEST_H

